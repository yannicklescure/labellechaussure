class Color < ApplicationRecord
  has_many :products
end

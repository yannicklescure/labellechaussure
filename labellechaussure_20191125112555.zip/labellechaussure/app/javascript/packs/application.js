import "bootstrap";

window.$ = $;
